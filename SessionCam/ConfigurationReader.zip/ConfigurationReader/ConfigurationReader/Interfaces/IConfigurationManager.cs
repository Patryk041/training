﻿namespace ConfigurationReader.Interfaces
{
    public interface IConfigurationManager
    {
        bool ShouldRefresh();
    }
}