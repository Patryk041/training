﻿using ConfigurationReader.Interfaces;

namespace ConfigurationReader
{
    public class ConfigurationManager  : IConfigurationManager
    {
        public bool ShouldRefresh()
        {
            throw new System.NotImplementedException();
        }
    }
}